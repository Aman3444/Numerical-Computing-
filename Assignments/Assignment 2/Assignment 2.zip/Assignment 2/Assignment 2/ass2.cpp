/*********************************************************************************************************************
Filename:			ass2.cpp
Version: 			1.0
Author:				Aman Multani
Student No:  		040 877 727
Course Name/Number:	Numerical Computing - CST8233
Lab Sect:
Assignment #:		2
Assignment name:	Linear Regression Least Squares Fit to Data
Due Date:			25 March 2018
Submission Date:	24 March 2018
Professor:			Andrew Tyler
Purpose: 			Allows the interpolation or extrapolation of the power and exponential growth of area with time;
*********************************************************************************************************************/

#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <math.h>

using namespace std;


/*File name to read*/
char* filename;
/*variable year*/
double* year;
/*variable for area */
double* AreaValue;
/*variable for displaying the data from the file*/
int Data;
/*variable for finding the Exponent of both the formulas*/
double Exp;

void displayMenu();
void loadFile();
void releaseMemory();
void power();
void exponential();

/*********************************************************************************************************
Function name:		main
Purpose:			main function for the displaying the main menu
In parameters:		none
Out parameters:
Version:			1.0
Author:				Aman Multani
**********************************************************************************************************/
int main()
{


	char input = '0';
	while (input != '2')
	{
		/*displaymenu() method is call*/
		displayMenu();
		cin >> input;

		switch (input)
		{
		case '1':
			/*calling the loadfile method use for reading the file */
			loadFile();
			break;
		case '2':
			/*quit option when selcted and release memory method is called */
			releaseMemory();
			break;
		default:
			/*if any other option is selected */
			cout << "Invalid inputs\n\n";
			continue;
		}
	}
}

/******************************************************************************************************
Function name:		displayFunctionTypeMenu
Purpose:			Displays the function type menu
In parameters:		None
Out parameters:		None
Version:			1.0
Author:				Aman Multani
*******************************************************************************************************/
void displayMenu()
{
	/*display the main menu when called */
	cout << "*******************************************************\n";
	cout << " Least-Sqares fit of Exponential and Power Law\n";
	cout << "1. Read Data from File\n";
	cout << "2. Quit\n";
	cout << "*******************************************************\n\n";
	cout << "Select an option: ";
}

/*****************************************************************************************************
Function name:		loadFile
Purpose:			Allows for the loading in of preformatted
values from a file.
In parameters:		None
Out parameters:		None
Version:			1.0
Author:				Aman Multani
************************************************************************************************************/
void loadFile()
{

	char buffer[256];
	int ch;
	cout << endl << "Please enter the name of the file to open: ";
	/*clears the error flag on cin*/
	cin.clear();
	/*skips to the next newline */
	cin.ignore(256, '\n');
	/*It assumes that buffer is an array of at least size characters*/
	cin.getline(buffer, 256);

	fstream file(buffer);
	/*check if the filename exist or not  */
	if (!file.is_open())
	{
		cout << "FAILED TO LOAD FILE" << endl;
		return;
	}
	cout << "FILE OPENED FOR READING" << endl;
	filename = new char[strlen(buffer) + 1];
	strcpy_s(filename, strlen(buffer) + 1, buffer);
	Data = 0;
	string line;
	/*redaing and counting the lines */
	while (getline(file, line))
	{
		++Data;
		//cout << line << endl;
	}
	/*display the total line in the file */
	cout << "There are " << Data << " records." << endl << endl;

	file.clear();
	/* get the length of the file */
	file.seekg(0, ios::beg);

	year = new double[Data];
	AreaValue = new double[Data];
	/*displaying the data from the file */
	for (int index = 0; index < Data; ++index)
	{
		file >> year[index];
		cout << year[index] << "   ";
		file >> AreaValue[index];
		cout << AreaValue[index] << endl;
	}
	cout << "File read into memory\n\n";
	/*displaying the second menu */
	while (1) {
		cout << "*******************************************************\n";
		cout << "1. Exponential fit to data\n";
		cout << "2. Power Law fit to data\n";
		cout << "3. Quit\n";
		cout << "*******************************************************\n\n";
		cout << "Select an option: ";
		cin >> ch;
		cout << "\n";
		if (ch == 1)exponential();
		if (ch == 2)power();
		if (ch == 3) {
			releaseMemory();
			exit(0);
		}
	}
	exit(0);
}

/**************************************************************************************************************
Function name:		releaseMemory
Purpose:			Releases or resets all memory that has been
allocated.
In parameters:		None
Out parameters:		None
Version:			1.0
Author:				Aman Multani
****************************************************************************************************************/
void releaseMemory()
{
	/*releasing the memory used by the variable */
	delete filename;
	delete AreaValue;
	delete year;

	Data = 0;
	Exp = 0;
}
/***********************************************************************************************************
Function name:		power
Purpose:			Calculates the least squares fit of a power formula.
In parameters:		char representing type of function
Out parameters:		None
Version:			1.0
Author:				Aman Multani
**************************************************************************************************************/
void power()
{
	/*varaible declaration and inisalization*/
	double SXY = 0.0;
	double SX = 0.0;
	double SY = 0.0;
	double SX_X = 0.0;
	double C = 0.0;
	double M = 0.0;
	double m = 0.0;
	char input = '0';

	/*calculating various parameters for least squares linear regression*/
	for (int index = 0; index < Data; ++index)
	{
		SXY += log(year[index] - 1935)*log(AreaValue[index]);
		SX += log(year[index] - 1935);
		SY += log(AreaValue[index]);
		SX_X += log(year[index] - 1935) * log(year[index] - 1935);
	}

	//cout << sumXY << endl << sumX << endl << sumY << endl << sumX_sq << endl;


	M = (Data*SX_X - SX*SX);
	m = (Data*SXY - SX*SY) / M;/*slope*/
	C = (SX_X*SY - SX*SXY) / M;/*constant*/
	Exp = exp(C);/*exponent of constnt*/

	cout << std::setprecision(4) << "POWER LAW A = " << Exp << "* (Y-1935)^" << m << "\n\n";
	while (input != '2')
	{
		cout << "*******************************************************" << endl;
		cout << "Interpolation/Extrapolation  of data Menu" << endl;
		cout << "1. Do an Interpolation/Extrapolation" << endl;
		cout << "2. Quit Interpolation/Extrapolation " << endl;
		cout << "*******************************************************\n" << endl;
		cout << "Select an option: ";

		cin >> input;
		cin.clear();
		cin.ignore(256, '\n');

		switch (input)
		{
		case '1':
			int inputYear;
			cout << "Power law Interpolation/Extrapolation of Toad area\n";
			cout << "Please enter the year(e.g. 2018) : ";
			cin >> inputYear;
			cout << setprecision(4) << "Toad area at " << inputYear << " = " << (Exp* pow((inputYear - 1935), m)) << " million square kilometres\n\n";
			break;
		case '2':
			break;
		default:
			cout << "Invalid inputs\n\n";
		}
	}



}

/******************************************************************************************************************************
Function name:		exponential
Purpose:			Calculates the least-squared fit for an exponential function.
In parameters:		char representing type of function
Out parameters:		None
Version:			1.0
Author:				Aman Multani
************************************************************************************************************************************/
void exponential()
{
	double SXY = 0;
	double SX = 0;
	double SY = 0;
	double SX_X = 0;
	double C = 0;
	double M = 0;
	double m = 0;
	char input = '0';


	for (int index = 0; index < Data; ++index)
	{
		SXY += (year[index] - 1939)*log(AreaValue[index]);
		SX += (year[index] - 1939);
		SY += log(AreaValue[index]);
		SX_X += (year[index] - 1939) * (year[index] - 1939);
	}

	//cout << sumXY << endl << sumX << endl << sumY << endl << sumX_sq << endl;
	M = (Data*SX_X - SX*SX);
	m = (Data*SXY - SX*SY) / M;
	C = (SX_X*SY - SX*SXY) / M;
	Exp = exp(C);

	cout << "EXPONENTIAL\n";
	cout << std::setprecision(4) << "A = " << Exp << "* exp(" << m << "*(Y-1939))\n\n";
	while (input != '2')
	{
		cout << "*******************************************************" << endl;
		cout << "Interpolation/Extrapolation of data Menu" << endl;
		cout << "1. Do an Interpolation/Extrapolation" << endl;
		cout << "2. Quit Interpolation/Extrapolation " << endl;
		cout << "*******************************************************\n" << endl;
		cout << "Select an option: ";

		cin >> input;
		cin.clear();
		cin.ignore(256, '\n');

		switch (input)
		{
		case '1':
			int inputYear;
			cout << "Exponential Interpolation/Extrapolation of Toad area\n";
			cout << "Please enter the year(e.g. 2018) : ";
			cin >> inputYear;
			cout << setprecision(4) << "Toad area at " << inputYear << " = " << (Exp* exp(m * (inputYear - 1939))) << " million square kilometres\n\n";
			break;
		case '2':
			break;
		default:
			cout << "Invalid inputs\n\n";
		}
	}
}

