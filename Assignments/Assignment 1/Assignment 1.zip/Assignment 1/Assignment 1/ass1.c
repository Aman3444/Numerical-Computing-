/********************************************************************************************************************************************************
Filename:			                ass1.cpp
Version:			                1.0
Student Name:		                Aman Multani
Student Number:		                040877727
Course Name/Number:                 Numerical computing CST8233
Lab Section:						
Assignment # :                      Assignment #1
Assignment Name:                    calculating Maclaurin  series in C
Due Date:                           Feb 25, 2018
Submission Date:                    Feb 25, 2018
Professor's Name:				    Andrew Tyler
List of Source and Header Files:	ass1.cpp
Purpose:							To display the main menu from which user can choice the function sinh 
									or cosh to calculate the maclaurin series of that function
**************************************************************************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main(void) {

	while (1) {
		/*variable declaration and intilalization*/
		int x = 0;
		int numTerms = 0;
		int i = 0;
		int j=0;
		printf("\n Evaluate the Maclaurin Series \n");
		printf("sin(hx) = 1/2 (exp(x) - exp(-x))\n");
		printf("cos(hx) = 1/2 (exp(x) + exp(-x))\n");
		printf("**********************************\n");
		printf("         Maclaurin Series\n Select the function to evaluate ");
		printf("\n1 = sinh(x)\n2 = cosh(x)\n3 - quit\n********************************** \n");
		/*taking in the non zero values fron the user*/
		scanf_s("%d", &x); 
		/*declaration*/
		double Term[6];
		double range =0.0;
		double Rexact = 0.0;
		double exactErr = 0.0;
		double seriesErr = 0.0;
		double value_term = 0.0;
		double result = 0.0;

		/*if option then go in do the work  */ 
		if (x == 1)
		{
			/*asking for the power of the X*/
			printf("\nEvaluating sinh series\n");
			printf("Please enter the highest power of x in the sinh series (1, 3, 5, 7, or 9):\n");
			/*a non zero vale is insert from gthe option given*/
			scanf_s("%d", &numTerms); 
			printf("order = %d", numTerms);

			/*if the condition is not macthing with the user then exit right away*/
			 if ((numTerms == 1) || (numTerms == 3) || (numTerms == 5) || (numTerms == 7) || (numTerms == 9)) { /*checks if number of terms between 1 & 6*/
				/*if the condition match to the users input then ask for the range from -10 to 10*/
				 printf("\nPlease enter the value of x at which to evaluate to in 10 increments from 0 (-10.0 through 10.0) : ");
				scanf_s("%lf", &range);
			}
			else {
				printf("Invalid Value");
				break;
				;
			}
			/*check if the range is between the given lenght then good other wise exit */
			if (range >= -10.0 && range <= 10.0) { /* checks if range between 1 & 4*/
				printf("\nMACLAURIN SERIES\n");
				/*print the power term and the range from 0 */
				printf("SINH MACLAURIN SERIES TO x ^%d from x = 0 to x = %lf\n", numTerms, range);
				printf("X\t\t Series\t\t Exact\t\tExactError\tTrunc.Error\n");
			}
			else{
				printf("Invalid Value");
				return EXIT_SUCCESS;
			}
			/*lfor getting the serires*/
			result = 0.0;
			Rexact = 0.5* (exp(value_term) - exp(-value_term));

			for (i = 0; i < 11; i++) { 
				result = 0.0;
				Term[0] = value_term;
				Term[1] = (value_term*value_term*value_term) / 6;
				Term[2] = (value_term*value_term*value_term*value_term*value_term) / 120;
				Term[3] = (value_term*value_term*value_term*value_term*value_term*value_term*value_term) / 5040;
				Term[4] = (value_term*value_term*value_term*value_term*value_term*value_term*value_term*value_term*value_term) / 362880;
				/*loop for the range inserted by the user*/

				for (j = 0; j < ((numTerms / 2) + 1); j++) {
					/*adding the trancated term and saving in the result*/
					result += Term[j]; 
				}
				Rexact = 0.5* (exp(value_term) - exp(-value_term));
				/* % Relative Exact Error (%RExactE) by comparison with the exact value from the math library */
					exactErr = 100 * (Rexact - result) / Rexact;
				/*% Relative Series Error(%RSerE) from the first truncated term*/
				seriesErr = 100 * (Term[numTerms] / result);
				printf("%.3e\t%.5e\t%.5e\t%.5e\t\t%.5e\n", value_term, result, Rexact, exactErr, seriesErr);
				value_term = value_term + (range / 10); 
			}

		}
		else if (x == 2) {
			printf("\nEvaluating cosh series\n");
			printf("Please enter the highest power of x in the cosh series (2, 4, 6, 8, or 10):\n");
			scanf_s("%d", &numTerms); 
			printf("order = %d", numTerms);
			if ((numTerms == 2) || (numTerms == 4) || (numTerms == 6) || (numTerms == 8) || (numTerms == 10)) { /*checks if number of terms between 1 & 6*/
				printf("\nPlease enter the value of x at which to evaluate to in 10 increments from 0 (-10.0 through 10.0) : ");
				scanf_s("%lf", &range);
			}
			else {
				printf("Invalid Value");
				break;
			}
			/*checking the range is in betweeen -10 to 10 */
			if (range >= -10.0 && range <= 10.0) { 
				printf("\nMACLAURIN SERIES\n");
				/*displaying the values taken by the users*/
				printf("COSH MACLAURIN SERIES TO x ^%d from x = 0 to x = %lf\n",numTerms,range );
				/*for the colums which will be displaed*/
				printf("X\t\t Series\t\t Exact\t\tExactError\tTrunc.Error\n");
			}
			else
			{
				printf("Invalid Value");
				break;
			}
			/*loops for the series value */
			for (i = 0; i < 11; i++) { 
				result = 0.0;
				Term[0] = 1;
				Term[1] = (value_term*value_term) / 2;
				Term[2] = (value_term*value_term*value_term*value_term) / 24;
				Term[3] = (value_term*value_term*value_term*value_term*value_term*value_term) / 720;
				Term[4] = (value_term*value_term*value_term*value_term*value_term*value_term*value_term*value_term) / 40320;
				Term[5] = (value_term*value_term*value_term*value_term*value_term*value_term*value_term*value_term*value_term*value_term) / 3628800;
				/*loop for the range inserted by the user*/
				for (j = 0; j < ((numTerms / 2) + 1); j++) { 
					result += Term[j]; 
				}			
				Rexact = 0.5* (exp(value_term) + exp(-value_term));
				/* % Relative Exact Error (%RExactE) by comparison with the exact value from the math library */
				exactErr = 100 * (Rexact - result) / Rexact;
				seriesErr = 100 * (Term[numTerms] / result);
				printf("%.3e\t%.5e\t%.5e\t%.5e\t\t%.5e\n", value_term, result, Rexact, exactErr, seriesErr);
				value_term = value_term + (range / 10); 
			}

		}
		else if (x == 3) {

			exit(0);
		}
		else
			break;

	}
}
