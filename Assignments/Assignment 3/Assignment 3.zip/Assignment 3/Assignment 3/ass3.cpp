#define _CRT_SECURE_NO_WARNINGS
#define _CRTDBG_MAP_ALLOC

#include <crtdbg.h>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <iomanip>
using namespace std;

bool running = true;
void earthquakeSimulation();

int main(void) {
	char selection;
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	while (running) {
		cout << "Earthquake Simulation" << endl;
		cout << "1. run the simulation" << endl;
		cout << "2. Quit" << endl;
		cin >> selection;
		switch (selection) {
		case '1':
			earthquakeSimulation();
			break;
		case '2':
			running = false;
			break;
		default:
			cout << endl << "Invalid Selection" << endl << endl;
			break;
		}
	}

}
/***********************************************************************************************************************************************
Function Name: earthquakeSimulation
Purpose: To perform the simulation of the effect earthquakes have on a building from given data.
In Parameters: None
Out Parameters: None - void
Version: 1.0
************************************************************************************************************************************************/
void earthquakeSimulation() {
	string fileName;
	string outputFileName;
	ifstream inputFile;
	ofstream outputFile;
	//for time values
	vector<double> tValues;
	//for ground movements
	vector<double> xValues;
	vector<double> buildingMovement;
	vector<double> groundAcceleration;
	vector <double> buildingVelocity;
	const double k = 20;
	const double b = 10;
	double t = 0;
	double v = 0;
	double x = 0;
	double a = 0;
	int numRows = 0;
	cin.ignore();
	cout << "Please enter the name of the earthquake file to open: ";
	getline(cin, fileName);
	inputFile.open(fileName);
	//if the file doesn't open correctly returns to menu
	if (!inputFile.is_open()) {
		cout << endl << "File Not Opened Correctly. Returning to menu." << endl;
		return;
	}
	//loops until the end of file. reads in the values from the file into the vectors that contain the time and ground movement values
	while (inputFile.good()) {
		double num;
		inputFile >> num;
		tValues.push_back(num);
		inputFile >> num;
		double num2 = num / 100;
		xValues.push_back(num2);
		numRows++;
	}
	inputFile.close();
	cout << endl << "File opened; " << numRows << " rows of data" << endl;
	for (int i = 0; i < numRows; i++) {
		if ((i >= 1) && (i < (numRows - 1))) {
			//calculation for ground acceleration
			a = (xValues.at(i + 1) - (2 * (xValues.at(i))) + xValues.at(i - 1)) / (0.0461*0.0461);
			groundAcceleration.push_back(a);
			a = groundAcceleration.at(i - 1) - (k * buildingMovement.at(i - 1)) - (b * buildingVelocity.at(i - 1));
			//calculating the building velocity and movement using the Euler method
			double veloc1 = buildingVelocity.at(i - 1) + (a * 0.0461);
			double xMovement = groundAcceleration.at(i - 1) - (k * buildingMovement.at(i - 1)) - (b * veloc1);
			//Heun's Method
			double veloc2 = buildingVelocity.at(i - 1) + ((a + xMovement) / 2) * 0.0461;
			double xMove2 = buildingMovement.at(i - 1) + veloc2 * 0.0461;

			buildingVelocity.push_back(veloc2);
			buildingMovement.push_back(xMove2);
		}
		else {
			buildingMovement.push_back(0);
			groundAcceleration.push_back(0);
			buildingVelocity.push_back(0);
		}
	}
	cout << "OPEN FILE TO SAVE" << endl;
	cout << "Please enter the name of the file to open: ";
	getline(cin, outputFileName);
	outputFile.open(outputFileName);
	//if the desired output file doesn't open correctly returns to menu
	if (!outputFile.is_open()) {
		cout << endl << "File not opened properly. Returning to menu." << endl;
		return;
	}
	//writes values from the calculations into the output file
	for (int i = 0; i < numRows; i++) {
		outputFile << tValues.at(i) << ", ";
		outputFile << xValues.at(i) << ", ";
		outputFile << groundAcceleration.at(i) << ", ";
		outputFile << buildingMovement.at(i) << ", ";
		outputFile << buildingVelocity.at(i) << ", " << endl;
	}
	outputFile.close();
}